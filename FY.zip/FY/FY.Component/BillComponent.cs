﻿using FY.Domain;
using FY.Manager;
using FY.Service;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FY.Component
{
    public class BillComponent:BaseComponent<Bill,BillManager>,IBillService
    {
        /// <summary>
        /// 创建公司总账单修改账目
        /// </summary>
        /// <param name="outRecords">销售单</param>
        public void Creates(OutRecords outRecords)
        {
            Bill lastBill =manager.GetAll().Last();
            lastBill.Remarks = "销售";
            lastBill.Money = outRecords.Money;
            lastBill.Balance += outRecords.Money;
            lastBill.UserId = outRecords.UserId;
            manager.Create(lastBill);
        }

        /// <summary>
        /// 创建公司总账单修改账目
        /// </summary>
        /// <param name="innRecords">进货单</param>
        public void Createss(InnRecords outRecords)
        {
            Bill lastBill = manager.GetAll().Last();
            lastBill.Remarks = "销售";
            lastBill.Money = outRecords.Money;
            lastBill.Balance -= outRecords.Money;
            lastBill.UserId = outRecords.UserId;
            manager.Create(lastBill);
        }
    }
}

﻿using FY.Domain;
using FY.Manager;
using FY.Service;
using NHibernate.Criterion;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FY.Component
{
    public class OutRecordComponent:BaseComponent<OutRecord,OutRecordManager>,IOutRecordService
    {
        public void CreateOutrecord(int shuliang, Goods goods, User user, string number, Customer customer1, Customer customer2)
        {
            //销售单创建
            OutRecord newOutRecord = new OutRecord();
            newOutRecord.OutQuantity = shuliang;
            newOutRecord.OutTime = System.DateTime.Now;
            newOutRecord.UserId =user;
            newOutRecord.GoodsId = goods;
            if (number == null)
            {
                newOutRecord.CustomerId = customer1;
                manager.Create(newOutRecord);
            }
            else
            {
                newOutRecord.CustomerId = customer2;
                manager.Create(newOutRecord);
            }
        }

        /// <summary>
        /// 查询时间间隔内订单数
        /// </summary>
        /// <param name="hitime">时间</param>
        /// <param name="lotime">时间</param>
        /// <returns></returns>
        public IList<OutRecord> BetweenTime(string hitime, string lotime)
        {
            IList<Order> listOrder = new List<Order>() { new Order("ID", true) };//设置一个排序集合
            int count = 0;
            DateTime Hitime = DateTime.Parse(hitime);
            DateTime Lotime = DateTime.Parse(lotime);
            IList<ICriterion> queryConditions = new List<ICriterion>();
            queryConditions.Add(Expression.Between("OutTime", Lotime, Hitime));

            //查询指定索引页的的商品信息
            IList<OutRecord> list = manager.GetPaged(queryConditions, listOrder, 1, 8, out count);
            return list;
        }

        //
        /// <summary>
        /// 判断时间格式
        /// </summary>
        /// <param name="time"></param>
        /// <returns></returns>
        public bool Time(string time)
        {
            if (time.Length == 16 && time[4].ToString() == "/" && time[7].ToString() == "/" && time[10].ToString() == " " && time[13].ToString() == ":")
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        //
        /// <summary>
        /// 收入计算
        /// </summary>
        /// <param name="list"></param>
        /// <returns></returns>
        public float pice(IList<OutRecord> list)
        {
            float a = 0;
            foreach (var item in list)
            {
                a = a + item.GoodsId.OutPrice * item.OutQuantity;
            }
            return a;
        }

        //
        /// <summary>
        /// 盈利计算
        /// </summary>
        /// <param name="list"></param>
        /// <returns></returns>
        public float pices(IList<OutRecord> list)
        {
            float a = 0;
            foreach (var item in list)
            {
                a = a + (item.GoodsId.OutPrice - item.GoodsId.InnPrice) * item.OutQuantity;
            }
            return a;
        }
    }
}

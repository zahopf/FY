﻿using FY.Domain;
using FY.Manager;
using FY.Service;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FY.Component
{
    public class KindComponent:BaseComponent<Kind,KindManager>,IKindService
    {
        /// <summary>
        /// 修改种类名
        /// </summary>
        /// <param name="id">对应id</param>
        public void Edits(Kind model)
        {
            Kind newKind = manager.Get(model.ID);
            newKind.KindName = model.KindName;
            manager.Update(newKind);
        }
    }
}

﻿using FY.Domain;
using FY.Manager;
using FY.Service;
using NHibernate.Criterion;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FY.Component
{
    public class OutRecordsComponent:BaseComponent<OutRecords,OutRecordsManager>,IOutRecordsService
    {
        
    }
}

﻿using FY.Domain;
using FY.Manager;
using FY.Service;
using NHibernate.Criterion;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;

namespace FY.Component
{
    public class CustomerComponent:BaseComponent<Customer,CustomerManager>,ICustomerService
    {
        /// <summary>
        /// 修改客户信息
        /// </summary>
        /// <param name="model"></param>
        public void NewUpdate(Customer model)
        {
            Customer newcustomer = manager.Get(model.ID);
            //为实体修改属性
            newcustomer.CustomerName = model.CustomerName;
            newcustomer.Number = model.Number;
            manager.Update(newcustomer);
        }


        /// <summary>
        /// 修改用户积分（VIP）
        /// </summary>
        /// <param name="number">用户电话</param>
        /// <param name="Money">消费额</param>
        public void Createintegral(string number, double Money)
        {
            if (number == null)
            {
                Customer customer = manager.Get(1);
                customer.Integral = Convert.ToInt32(Money) + customer.Integral;
                manager.Update(customer);
            }
            else
            {
                //客户查询
                List<ICriterion> customerNumber = new List<ICriterion>();
                customerNumber.Add(new LikeExpression("Number", number));
                //客户积分修改
                Customer customer = manager.Get(customerNumber);
                customer.Integral = Convert.ToInt32(Money) + customer.Integral;
                if (customer.Integral >= 2000)//积分大于2000自动变为VIp
                {
                    customer.VIP = true;
                }
                manager.Update(customer);
            }
        }

        /// <summary>
        /// 根据number查询客户
        /// </summary>
        /// <param name="Number"></param>
        /// <returns></returns>
        public Customer TFnumber(string Number)
        {
            if (Number == null)
            {
                //默认散客
                return manager.Get(1);
            }
            else
            {
                //老客户查询
                List<ICriterion> customerNumber = new List<ICriterion>();
                customerNumber.Add(new LikeExpression("Number",Number));
                return manager.Get(customerNumber);
            }
        }
    }
}

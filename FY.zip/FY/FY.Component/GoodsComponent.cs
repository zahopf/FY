﻿using FY.Domain;
using FY.Manager;
using FY.Service;
using NHibernate.Criterion;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;

namespace FY.Component
{
    public class GoodsComponent:BaseComponent<Goods,GoodsManager>,IGoodsService
    {
        /// <summary>
        /// 修修改库存
        /// </summary>
        /// <param name="model"></param>
        public Goods CreateInnRecord(Goods model,InnRecord item)
        {
            //根据ID查询货物
            Goods newgoods = manager.Get(model.ID);
            //修改库存
            newgoods.Stock = item.InnQuantity + newgoods.Stock;
            //修改跟新数据库
            manager.Update(newgoods);
            return newgoods;
        }

        /// <summary>
        /// 库存修改
        /// </summary>
        /// <param name="OutQuantity">改变数量</param>
        /// <param name="Id">GoodsId</param>
        public bool Updatestock(int OutQuantity, int Id)
        {
            Goods newgoods = manager.Get(Id);//修改的商品
            newgoods.Stock -= OutQuantity;
            if (newgoods.Stock >= 0)
            {
                manager.Update(newgoods);//存入数据库
                return true;
            }
            return false;
        }

        /// <summary>
        /// 把货物实体转化为能为Html.DropDownListFor使用的格式（只取名字）
        /// </summary>
        /// <param name="listgoods"> 传入的商品列表</param>
        /// <returns></returns>
        public List<SelectListItem> GetGoodsnameList(IList<Goods> listgoods)
        {
            List<SelectListItem> goodsList = new List<SelectListItem>();
            foreach (Goods goodsname in listgoods)
            {
                goodsList.Add(new SelectListItem { Text = goodsname.GoodsName, Value = goodsname.GoodsName });
            }
            return goodsList;
        }

        /// <summary>
        /// 把货物实体转化为能为Html.DropDownListFor使用的List《SelectListItem》格式（只取名字）
        /// </summary>
        /// <param name="listKind"></param>
        /// <returns></returns>
        public List<SelectListItem> GetKindnameList(IList<Kind> listKind)
        {
            List<SelectListItem> kindList = new List<SelectListItem>();
            //kindList.Add(Expression.IsNotNull("ID"));
            foreach (Kind kindname in listKind)
            {
                kindList.Add(new SelectListItem { Text = kindname.KindName, Value = kindname.ID.ToString() });

            }
            return kindList;
        }

        /// <summary>
        /// 根据名字查询商品
        /// </summary>
        /// <param name="goodsName"></param>
        /// <param name="pageIndex"></param>
        /// <param name="count"></param>
        /// <returns></returns>
        public IList<Goods> PageLists(string goodsName, int pageIndex, int count)
        {
            IList<ICriterion> queryConditions = new List<ICriterion>();
            //if (!string.IsNullOrEmpty(goodsName))
            //{
            //    queryConditions.Add(Expression.Or(
            //        Expression.Eq("GoodsName", goodsName),
            //        Expression.Eq("KindId.KindName", goodsName)
            //        ));
            //}
            if (!string.IsNullOrEmpty(goodsName))
            {
                queryConditions.Add(
                    Expression.Eq("GoodsName", goodsName)
                    );
            }

            //3设置排序表达式集合(必须的修改)
            IList<Order> listOrder = new List<Order>() { new Order("ID", true) };//设置一个排序集合，new Order("ID", true)表示：根据ID排序,true代表升序,false代表降序

            //4通过容器调用分页方法(修改查询的数据类型)
            IList<Goods> list = manager.GetPaged(queryConditions, listOrder, pageIndex, 21, out count);
            return list;
        }


        //public IList<Goods> PageListss(string goodsName, int pageIndex, int count)
        //{
        //    IList<ICriterion> queryConditions = new List<ICriterion>();
        //    if (!string.IsNullOrEmpty(goodsName))
        //    {
        //        queryConditions.Add(new LikeExpression("KindList.KindName", goodsName));
        //    }

        //    //3设置排序表达式集合(必须的修改)
        //    IList<Order> listOrder = new List<Order>() { new Order("ID", true) };//设置一个排序集合，new Order("ID", true)表示：根据ID排序,true代表升序,false代表降序

        //    //4通过容器调用分页方法(修改查询的数据类型)
        //    IList<Goods> list = manager.GetPaged(queryConditions, listOrder, pageIndex, 21, out count);
        //    return list;
        //}

        
    }
}

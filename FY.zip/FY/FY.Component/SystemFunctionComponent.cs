﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FY.Domain;
using FY.Manager;
using FY.Service;

namespace FY.Component
{
    public class SystemFunctionComponent : BaseComponent<SystemFunction,SystemFunctionManager>,ISystemFunctionService
    {
       
    }
}

﻿using FY.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FY.Service
{
    public interface IKindService:IBaseService<Kind>
    {
        /// <summary>
        /// 修改种类名
        /// </summary>
        /// <param name="model">对应种类</param>
        void Edits(Kind model);
    }
}

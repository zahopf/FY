﻿using FY.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FY.Service
{
    public interface IBillService:IBaseService<Bill>
    {
        /// <summary>
        /// 创建公司总账单修改账目
        /// </summary>
        /// <param name="outRecords">销售单</param>
        void Creates(OutRecords outRecords);

        /// <summary>
        /// 创建公司总账单修改账目
        /// </summary>
        /// <param name="innRecords">进货单</param>
        void Createss(InnRecords outRecords);
    }
}

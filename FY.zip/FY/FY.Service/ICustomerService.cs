﻿using FY.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;

namespace FY.Service
{
    public interface ICustomerService:IBaseService<Customer>
    {
        /// <summary>
        /// 修改客户信息
        /// </summary>
        /// <param name="model"></param>
        void NewUpdate(Customer model);

        /// <summary>
        /// 修改用户积分
        /// </summary>
        /// <param name="number">用户电话</param>
        /// <param name="Money">消费额</param>
        void Createintegral(string number,double Money);

        /// <summary>
        /// 根据number查询客户
        /// </summary>
        /// <param name="Number"></param>
        /// <returns></returns>
        Customer TFnumber(string Number);
    }
}

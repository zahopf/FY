﻿using FY.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;

namespace FY.Service
{
    public interface IGoodsService:IBaseService<Goods>
    {
        /// <summary>
        /// 修修改库存建立进货记录
        /// </summary>
        /// <param name="model"></param>
        Goods CreateInnRecord(Goods model,InnRecord item);

        /// <summary>
        /// 获取商品名
        /// </summary>
        /// <param name="listgoods">传入的商品List</param>
        /// <returns></returns>
        List<SelectListItem> GetGoodsnameList(IList<Goods> listgoods);

        /// <summary>
        /// 获取商品种类名
        /// </summary>
        /// <param name="listKind"></param>
        /// <returns></returns>
        List<SelectListItem> GetKindnameList(IList<Kind> listKind);

        /// <summary>
        /// 获取所有商品的信息
        /// </summary>
        /// <param name="userName"></param>
        /// <param name="pageIndex"></param>
        /// <returns></returns>
        IList<Goods> PageLists(string userName,int pageIndex,int count);

        /// <summary>
        /// 库存修改
        /// </summary>
        /// <param name="OutQuantity">改变数量</param>
        /// <param name="Id">GoodsId</param>
        bool Updatestock(int OutQuantity,int Id);
    }

}

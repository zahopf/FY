﻿using FY.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FY.Service
{
    public interface IOutRecordService:IBaseService<OutRecord>
    {
        /// <summary>
        /// 销售单创建
        /// </summary>
        /// <param name="shuliang">销售数量</param>
        /// <param name="goods">商品</param>
        /// <param name="userId">销售人</param>
        /// <param name="number">客户电话</param>
        void CreateOutrecord(int shuliang, Goods goods, User user, string number, Customer customer1, Customer customer2);

        /// <summary>
        /// 查询时间间隔内订单数
        /// </summary>
        /// <param name="hitime">时间</param>
        /// <param name="lotime">时间</param>
        /// <returns></returns>
        IList<OutRecord> BetweenTime(string hitime, string lotime);

        /// <summary>
        /// 收入计算
        /// </summary>
        /// <param name="list">订单集合</param>
        /// <returns></returns>
        float pice(IList<OutRecord> list);

        /// <summary>
        /// 盈利计算
        /// </summary>
        /// <param name="list">订单集合</param>
        /// <returns></returns>
        float pices(IList<OutRecord> list);

        /// <summary>
        /// 时间格式判断
        /// </summary>
        /// <param name="time">订单集合</param>
        /// <returns></returns>
        bool Time(string time);
    }
}

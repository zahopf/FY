﻿using FY.Core;
using FY.Domain;
using FY.Manager;
using FY.Service;
using FY.Web.Apps;
using NHibernate.Criterion;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace FY.Web.Controllers
{
    public class GoodsController : BaseController
    {
        #region 商品管理
        public List<SelectListItem> listProductTypes()
        {
            List<SelectListItem> listProductTypes = new List<SelectListItem>();
            listProductTypes.Add(new SelectListItem() { Text = "折扣" }
            );
            for (double i = 1; i > 0; )
            {
                listProductTypes.Add(new SelectListItem() { Text = i.ToString() });
                i -= 0.1;
                if (i == 0.1)
                    continue;
            }
            return listProductTypes;
        }
        public ActionResult Index(string goodsName, string Number, int pageIndex = 1)
        {
                ViewBag.Number = listProductTypes();

            IList<ICriterion> queryConditions = new List<ICriterion>();
            if (!string.IsNullOrEmpty(goodsName))
            {
                queryConditions.Add(Expression.Eq("GoodsName", goodsName));
            }
            if (Number != "折扣" && !string.IsNullOrEmpty(Number))
            {
                queryConditions.Add(Expression.Eq("Number", Convert.ToSingle(Number)));
            }
            IList<Order> listOrder = new List<Order>() { new Order("ID", true) };//设置一个排序集合
            int count = 0;
            //查询指定索引页的的商品信息
            IList<Goods> list = Container.Instance.Resolve<IGoodsService>().GetPaged(queryConditions, listOrder, pageIndex, PagerHelper.PageSize, out count);

            //将结果转换为PageList对象，以供分页控件使用
            PageList<Goods> pageList = list.ToPageList<Goods>(pageIndex,PagerHelper.PageSize, count);

            return View(pageList);
        }

        #endregion


        #region 进货界面
        [HttpGet]
        public ActionResult InnGoods()
        { 
            InnRecords innRecords = new InnRecords();
            innRecords.InnRecordlist = new List<InnRecord>() { new InnRecord() };
            return View(innRecords);
        }

        [HttpPost]
        public ActionResult InnGoods(InnRecords model)
        {
            //创建经货单基本数据
            InnRecords newInnRecords = new InnRecords();
            newInnRecords.Time = DateTime.Now;
            newInnRecords.UserId = AppHelper.LoginedUser;
            newInnRecords.InnRecordlist = model.InnRecordlist;

            //写入进货数据
            foreach (var item in model.InnRecordlist)
            {
                //查询当前进货商品
                List<ICriterion> goodsName = new List<ICriterion>();
                goodsName.Add(Expression.Eq("GoodsName", item.GoodsId.GoodsName));
                Goods goods = Container.Instance.Resolve<IGoodsService>().Get(goodsName);

                //判断进货数和商品
                if (item.InnQuantity == 0 || goods == null)
                {
                    ViewBag.TF = 0;
                    return View(model);
                }

                //创建订单明细
                item.InnTime = newInnRecords.Time;
                item.UserId = AppHelper.LoginedUser;
                item.GoodsId = goods;
                item.Number = newInnRecords;
                item.KindId = goods.KindId;

                //创建订单信息
                newInnRecords.Money += (item.GoodsId.InnPrice * item.InnQuantity);
                newInnRecords.Quantity += item.InnQuantity;

                //跟新商品库存
                Container.Instance.Resolve<IGoodsService>().CreateInnRecord(item.GoodsId,item);
            }

            //公司总账单改变修改(重写Create方法)
            Container.Instance.Resolve<IBillService>().Createss(newInnRecords);

            //保存到数据库（保存进货单和进货明细）
            Container.Instance.Resolve<IInnRecordsService>().Create(newInnRecords);
            return View(newInnRecords);
            
        }
        #endregion


        #region 销售页

        [HttpGet]
        public ActionResult Sell()
        {
            //实例化订单
            OutRecords outRecords = new OutRecords();
            outRecords.OutRecordlist = new List<OutRecord>() { new OutRecord() };
            //传入销售员
            ViewBag.UserList = Container.Instance.Resolve<IUserService>().GetAll();
            return View(outRecords);
        }
        [HttpPost]
        public ActionResult Sell(OutRecords model)
        {
            ViewBag.UserList = Container.Instance.Resolve<IUserService>().GetAll();
            //创建售货单
            OutRecords outRecords = new OutRecords();
            outRecords.Time = DateTime.Now;
            outRecords.UserId = Container.Instance.Resolve<IUserService>().Get(model.UserId.ID);
            outRecords.OutRecordlist = model.OutRecordlist;
            outRecords.CustomerId = Container.Instance.Resolve<ICustomerService>().TFnumber(model.CustomerId.Number);//TFnumber(model.CustomerId.Number)判断客户or散客并赋值

            foreach (var item in model.OutRecordlist)
            {
                //查询当前出售货物
                List<ICriterion> goodsName = new List<ICriterion>();
                goodsName.Add(Expression.Eq("GoodsName", item.GoodsId.GoodsName));
                Goods newGoods = Container.Instance.Resolve<IGoodsService>().Get(goodsName);

                //判断进货数和商品
                if (item.OutQuantity == 0 || newGoods == null || outRecords.CustomerId==null)
                {
                    ViewBag.TF = 0;
                    return View(model);
                }

                //销售单明细信息写入
                item.OutTime = outRecords.Time;
                item.UserId = outRecords.UserId;
                item.GoodsId = newGoods;
                item.CustomerId = outRecords.CustomerId;
                item.Number = outRecords;

                //销售单信息写入
                outRecords.Quantity += item.OutQuantity;
                outRecords.Money += (item.OutQuantity * newGoods.OutPrice*newGoods.Number);

                //根据id和数量库存修改并判断库存是否足够
                if(!Container.Instance.Resolve<IGoodsService>().Updatestock(item.OutQuantity, newGoods.ID))
                {
                    ViewBag.TF = 0;
                    return View(outRecords); 
                }
            }

            //VIP全场95折
            if (outRecords.CustomerId.VIP == true)
            {
                outRecords.Money = outRecords.Money * 0.95;
            }

            //根据number修改用户积分（VIP）
            Container.Instance.Resolve<ICustomerService>().Createintegral(model.CustomerId.Number,outRecords.Money);

            //公司总账单改变修改(重写Create方法)
            Container.Instance.Resolve<IBillService>().Creates(outRecords);

            //保存到数据库（保存销售单和销售明细）
            Container.Instance.Resolve<IOutRecordsService>().Create(outRecords);
            return View(outRecords);
        }

        
        #endregion


        #region 查询
        [HttpGet]
        public ActionResult Lookup()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Lookup(int pageIndex = 1, string goodsName = "")
        {
            int count = 0;//用于存放满足条件的记录总

            //将获取list对象的存放到PageList对象中
            PageList<Goods> pageList = Container.Instance.Resolve<IGoodsService>().PageLists(goodsName, pageIndex, count).ToPageList<Goods>(pageIndex,PagerHelper.PageSize, count);
            return View(pageList); 
        }
        #endregion


        #region 添加商品
        [HttpGet]
        public ActionResult Create()//这个方法用于mvc展示页面
        {
            Goods goods = new Goods();//实体化一个空的实体

            ViewBag.KindList = Container.Instance.Resolve<IKindService>().GetAll();

            return View(goods);//用一个视图展示goods
        }

        [HttpPost]
        public ActionResult Create(Goods model)
        {
            //重新传入商品种类
            ViewBag.KindList = Container.Instance.Resolve<IKindService>().GetAll();
            //模型验证
            if (ModelState.IsValid)
            {
                model.Stock = 0;//库存初始化
                model.Number = 1;//初始化折扣
                model.KindId = Container.Instance.Resolve<IKindService>().Get(model.KindId.ID);//种类
                List<ICriterion> goodsName = new List<ICriterion>();
                goodsName.Add(Expression.Eq("GoodsName", model.GoodsName));

                if (Container.Instance.Resolve<IGoodsService>().Exists(goodsName))
                {
                    ModelState.AddModelError("GoodsName", "此名字已存在");
                    return View(model);
                }
                else
                {
                    Container.Instance.Resolve<IGoodsService>().Create(model);
                    return RedirectToAction("Index");
                }
            }
            return View(model);
        }
        #endregion


        #region 删除商品
        public ActionResult Delete(int id)
        {
            Container.Instance.Resolve<IGoodsService>().Delete(id);
            return RedirectToAction("Index");//跳转到列表视图
        }
        #endregion


        #region 修改基本信息
        [HttpGet]
        public ActionResult Edit(int id)
        {
            //根据商品id查询商品
            Goods model = Container.Instance.Resolve<IGoodsService>().Get(id);
            //传入商品种类
            ViewBag.KindList = Container.Instance.Resolve<IKindService>().GetAll();
            //调用创建视图
            return View("Create", model);
        }
        [HttpPost]
        public ActionResult Edit(Goods model)
        {
            ViewBag.KindList = Container.Instance.Resolve<IKindService>().GetAll();
            model.KindId = Container.Instance.Resolve<IKindService>().Get(model.KindId.ID);//种类
            if (ModelState.IsValid)
            {
                List<ICriterion> goodsName = new List<ICriterion>();
                goodsName.Add(Expression.Eq("GoodsName", model.GoodsName));
                //名字相同通过
                if (Container.Instance.Resolve<IGoodsService>().Get(model.ID).GoodsName == model.GoodsName)
                {
                    Container.Instance.Resolve<IGoodsService>().Update(model);
                    return RedirectToAction("Index");
                }
                //不同验则证纯在
                if (Container.Instance.Resolve<IGoodsService>().Exists(goodsName))
                {
                    ModelState.AddModelError("GoodsName", "此名字已存在");
                    return View("Create", model);
                }
                else
                {
                    Container.Instance.Resolve<IGoodsService>().Update(model);
                    return RedirectToAction("Index");
                }
            }
            return View("Create", model);
            
        }
        #endregion
    }
}
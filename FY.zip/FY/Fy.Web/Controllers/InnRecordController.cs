﻿using FY.Core;
using FY.Domain;
using FY.Service;
using FY.Web.Apps;
using NHibernate.Criterion;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace FY.Web.Controllers
{
    public class InnRecordController : BaseController
    {
        #region 进货记录
        public ActionResult Index(int pageIndex = 1)
        {
            IList<Order> listOrder = new List<Order>() { new Order("Time",false) };//设置一个排序集合
            int count = 0;
            //查询指定索引页的的角色信息
            IList<InnRecords> list = Container.Instance.Resolve<IInnRecordsService>().GetPaged(null, listOrder, pageIndex, PagerHelper.PageSize, out count);
            //将结果转换为PageList对象，以供分页控件使用
            PageList<InnRecords> pageList = list.ToPageList<InnRecords>(pageIndex, PagerHelper.PageSize, count);
            return View(pageList);
        }
        #endregion

        #region 进货记录
        public ActionResult Indexs(int id,int pageIndex = 1)
        {
            IList<ICriterion> queryConditions = new List<ICriterion>();
            queryConditions.Add(Expression.Eq("Number.ID", id));
            IList<Order> listOrder = new List<Order>() { new Order("InnTime", false) };//设置一个排序集合
            int count = 0;
            //查询指定索引页的的角色信息
            IList<InnRecord> list = Container.Instance.Resolve<IInnRecordService>().GetPaged(queryConditions, listOrder, pageIndex, PagerHelper.PageSize, out count);
            //将结果转换为PageList对象，以供分页控件使用
            PageList<InnRecord> pageList = list.ToPageList<InnRecord>(pageIndex, PagerHelper.PageSize, count);
            return View(pageList);
        }
        #endregion
        
    }
}
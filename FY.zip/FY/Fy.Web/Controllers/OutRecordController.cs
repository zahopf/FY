﻿using FY.Core;
using FY.Domain;
using FY.Service;
using FY.Web.Apps;
using NHibernate.Criterion;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace FY.Web.Controllers
{
    public class OutRecordController : BaseController
    {
        #region 销售记录
        public ActionResult Index(int pageIndex = 1)
        {
            IList<Order> listOrder = new List<Order>() { new Order("Time", false) };//设置一个排序集合
            int count = 0;
            //查询指定索引页的的角色信息
            IList<OutRecords> list = Container.Instance.Resolve<IOutRecordsService>().GetPaged(null, listOrder, pageIndex, PagerHelper.PageSize, out count);
            //将结果转换为PageList对象，以供分页控件使用
            PageList<OutRecords> pageList = list.ToPageList<OutRecords>(pageIndex, PagerHelper.PageSize, count);
            return View(pageList);
        }
        #endregion

        #region 详细销售记录
        public ActionResult Indexs(int id, int pageIndex = 1)
        {
            IList<ICriterion> queryConditions = new List<ICriterion>();
            queryConditions.Add(Expression.Eq("Number.ID", id));
            IList<Order> listOrder = new List<Order>() { new Order("OutTime", false) };//设置一个排序集合
            int count = 0;
            //查询指定索引页的的角色信息
            IList<OutRecord> list = Container.Instance.Resolve<IOutRecordService>().GetPaged(queryConditions, listOrder, pageIndex, PagerHelper.PageSize, out count);
            //将结果转换为PageList对象，以供分页控件使用
            PageList<OutRecord> pageList = list.ToPageList<OutRecord>(pageIndex, PagerHelper.PageSize, count);
            return View(pageList);
        }
        #endregion


        #region 销售总结
        public void Allprice()
        {
            IList<Order> listOrder = new List<Order>() { new Order("ID", true) };//设置一个排序集合
            int count = 0;
            //所有盈利
            IList<OutRecord> lists = Container.Instance.Resolve<IOutRecordService>().GetPaged(null, listOrder,1, PagerHelper.PageSize, out count);
            //向视图传递数据
            ViewBag.B = Container.Instance.Resolve<IOutRecordService>().pice(lists); ViewBag.C = Container.Instance.Resolve<IOutRecordService>().pices(lists);//pice收入pices盈利
            ViewBag.D = Container.Instance.Resolve<IOutRecordService>().pices(lists) / Container.Instance.Resolve<IOutRecordService>().pice(lists); ViewBag.E = lists.Count();
            ViewBag.Hvalue = "请输入";
            ViewBag.Lvalue = "请输入";
            ViewBag.first = lists.FirstOrDefault().OutTime;
            ViewBag.last = lists.LastOrDefault().OutTime;
        }
        [HttpGet]
        public ActionResult Profit( int pageIndex = 1)
        {
            Allprice();//所有盈利
            PageList<OutRecord> pageList = null;
            return View(pageList);
        }
        [HttpPost]
        public ActionResult Profit(string hitime = "", string lotime = "", int pageIndex = 1)
        {
            Allprice();//所有盈利
            
            //指定时间间隔盈利
            if (Container.Instance.Resolve<IOutRecordService>().Time(hitime) && Container.Instance.Resolve<IOutRecordService>().Time(lotime))//判断时间格式
            {
                ////查询指定索引页的的商品信息
                IList<OutRecord> list = Container.Instance.Resolve<IOutRecordService>().BetweenTime(hitime, lotime);
                //传递数据
                ViewBag.A = Container.Instance.Resolve<IOutRecordService>().pice(list); ViewBag.F = Container.Instance.Resolve<IOutRecordService>().pices(list);
                ViewBag.G = Container.Instance.Resolve<IOutRecordService>().pices(list) / Container.Instance.Resolve<IOutRecordService>().pice(list);

                //返回时间
                ViewBag.Hvalue =hitime;
                ViewBag.Lvalue =lotime;
                //将结果转换为PageList对象，以供分页控件使用
                int count = 0;
                PageList<OutRecord> pageList = list.ToPageList<OutRecord>(pageIndex, PagerHelper.PageSize, count);
                return View(pageList);
            }
            PageList<OutRecord> pageLists = null;
            return View(pageLists);
        }
        #endregion
    }
}
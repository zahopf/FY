﻿using FY.Core;
using FY.Domain;
using FY.Service;
using FY.Web.Apps;
using FY.Web.Controllers;
using NHibernate.Criterion;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Fy.Web.Controllers
{
    public class CustomerController : BaseController
    {
        #region 客户集合
        public ActionResult Index(int pageIndex = 1, string customerName = "")
        {
            //组织查询条件
            IList<ICriterion> queryConditions = new List<ICriterion>();
            if (!string.IsNullOrEmpty(customerName))
            {
                //根据用户名或电话查询
                queryConditions.Add(Expression.Or(
                    Expression.Eq("CustomerName", customerName),
                    Expression.Eq("Number", customerName)
                    ));
            }

            int count = 0;//用于存放满足条件的记录总

            IList<Order> listOrder = new List<Order>() {new Order("ID", true)};//设置一个排序集合

            //通过容器调用分页方法(修改查询的数据类型)
            IList<Customer> list = Container.Instance.Resolve<ICustomerService>().GetPaged(queryConditions, listOrder, pageIndex, PagerHelper.PageSize, out count);

            //将list对象存放到PageList对象中,同时将分页的相关属性也包含在其中
            PageList<Customer> pageList = list.ToPageList<Customer>(pageIndex, PagerHelper.PageSize, count);

            return View(pageList);
        }
        #endregion


        #region 删除客户
        public ActionResult Delete(int id)
        {
            Container.Instance.Resolve<ICustomerService>().Delete(id);
            return RedirectToAction("Index");//跳转到列表视图
        }
        #endregion


        #region 修改基本信息
        [HttpGet]
        public ActionResult Edit(int id)
        {
            Customer customer = Container.Instance.Resolve<ICustomerService>().Get(id);
            return View( "Create",customer);
        }

        [HttpPost]
        public ActionResult Edit(Customer model)
        {
            

            if (ModelState.IsValid)
            {
                List<ICriterion> queryConditions = new List<ICriterion>();
                queryConditions.Add(Expression.Eq("Number", model.Number));
                if (model.Number == Container.Instance.Resolve<ICustomerService>().Get(model.ID).Number)//若果没修改则通过
                {
                    Container.Instance.Resolve<ICustomerService>().NewUpdate(model); //修改信息
                    return RedirectToAction("Index");//跳转到列表视图
                }
                if (Container.Instance.Resolve<ICustomerService>().Exists(queryConditions))//判断是否存在
                {
                    ModelState.AddModelError("Number", "电话号码已存在");//返回提示信息
                    return View("Create", model);
                }
                else
                {
                    Container.Instance.Resolve<ICustomerService>().NewUpdate(model); //修改信息
                    return RedirectToAction("Index");//跳转到列表视图
                }
            }
            return View("Create",model);
        }
        #endregion


        #region 添加用户
        [HttpGet]
        public ActionResult Create()
        {
            Customer customer = new Customer();//实体化一个空的实体
            return View("Create", customer);
        }

        [HttpPost]
        public ActionResult Create(Customer customer)
        {
            customer.Integral = 0;//初始化积分
            if (ModelState.IsValid)
            {
                //判断是否存在
                List<ICriterion> queryConditions = new List<ICriterion>();
                queryConditions.Add(Expression.Eq("Number", customer.Number));
                if (Container.Instance.Resolve<ICustomerService>().Exists(queryConditions))
                {
                    ModelState.AddModelError("Number", "电话号码已存在");//返回提示信息
                    return View("Create", customer);
                }
                else
                {
                    Container.Instance.Resolve<ICustomerService>().Create(customer);
                    return RedirectToAction("Index");//跳转到Index页面
                }    
            }
            return View(customer);
        }
        #endregion
	}
}
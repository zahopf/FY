﻿using FY.Core;
using FY.Domain;
using FY.Service;
using FY.Web.Apps;
using NHibernate.Criterion;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace FY.Web.Controllers
{
    public class KindController : BaseController
    {
        #region 商品种类显示
        public ActionResult Index(int pageIndex = 1)
        {

            int count = 0;
            IList<Kind> list = Container.Instance.Resolve<IKindService>() .GetPaged(null, null, pageIndex,PagerHelper.PageSize, out count);

            PageList<Kind> pageList = list.ToPageList<Kind>(pageIndex,PagerHelper.PageSize, count);
            return View(pageList);
        }
        #endregion


        #region 创建种类
        [HttpGet]
        public ActionResult Create()
        {
            //定义一个新对象传入视图
            Kind role = new Kind();
            return View(role);
        }

        [HttpPost]
        public ActionResult Create(Kind kind)
        {
            //准备查询条件
            List<ICriterion> newKind = new List<ICriterion>();
            newKind.Add(Expression.Eq("KindName", kind.KindName));
            //判断是否未输入
            if (kind.KindName == null)
            {
                ModelState.AddModelError("KindName", "不能为空");
                return View(kind);
            }
            //重复检测
            if (Container.Instance.Resolve<IKindService>().Exists(newKind))
            {
                ModelState.AddModelError("KindName", "此名字已存在");
                return View(kind);
            }
            else
            {
                //创建新种类
                Container.Instance.Resolve<IKindService>().Create(kind);
                return RedirectToAction("Index");
            }
        }
        #endregion


        #region 删除
        public ActionResult Delete(int id)
        {
            //根据ID查询种类信息
            Kind model = Container.Instance.Resolve<IKindService>().Get(id);

            //判断种类是否已分配了商品，如果有，则不能删除
            if (model.GoodsList == null || model.GoodsList.Count == 0)
                Container.Instance.Resolve<IKindService>().Delete(model);

            //跳转到Index页面
            return RedirectToAction("Index");
        }
        #endregion    


        #region 修改
        [HttpGet]
        public ActionResult Edit(int id)
        {
            //根据id获取实体
            Kind model = Container.Instance.Resolve<IKindService>().Get(id);
            return View("Create", model);
        }
        [HttpPost]
        public ActionResult Edit(Kind model)
        {
            List<ICriterion> kindName = new List<ICriterion>();
            kindName.Add(Expression.Eq("KindName", model.KindName));
            //判断是否未输入
            if (model.KindName == null)
            {
                ModelState.AddModelError("KindName", "不能为空");
                return View("Create", model);
            }
            //若果未修改则保存原来信息
            if (Container.Instance.Resolve<IKindService>().Get(model.ID).KindName == model.KindName)
            {
                Container.Instance.Resolve<IKindService>().Edits(model);//调用Edits修改种类信息
                return RedirectToAction("Index");
            }
            //如修改判断是否存在再修改
            if (Container.Instance.Resolve<IKindService>().Exists(kindName))
            {
                ModelState.AddModelError("KindName", "此名字已存在");
                return View("Create", model);
            }
            else
            {
                Container.Instance.Resolve<IKindService>().Edits(model);//调用Edits修改种类信息
                return RedirectToAction("Index");
            }
        }
        #endregion


        #region

        #endregion
    }
}
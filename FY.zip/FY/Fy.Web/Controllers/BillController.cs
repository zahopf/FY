﻿using FY.Core;
using FY.Domain;
using FY.Service;
using FY.Web.Apps;
using FY.Web.Controllers;
using NHibernate.Criterion;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Fy.Web.Controllers
{
    public class BillController : BaseController
    {
        public ActionResult Index(int pageIndex = 1, string remarksName = "")
        {
            //组织查询条件
            IList<ICriterion> queryConditions = new List<ICriterion>();
            if (!string.IsNullOrEmpty(remarksName))
            {
                //根据用户名或电话查询
                queryConditions.Add(Expression.Eq("Remarks", remarksName));
            }

            int count = 0;//用于存放满足条件的记录总

            IList<Order> listOrder = new List<Order>() { new Order("ID",false) };//设置一个排序集合

            //通过容器调用分页方法(修改查询的数据类型)
            IList<Bill> list = Container.Instance.Resolve<IBillService>().GetPaged(queryConditions, listOrder, pageIndex, PagerHelper.PageSize, out count);

            //将list对象存放到PageList对象中,同时将分页的相关属性也包含在其中
            PageList<Bill> pageList = list.ToPageList<Bill>(pageIndex, PagerHelper.PageSize, count);

            return View(pageList);
        }
	}
}
﻿using FY.Core;
using FY.Domain;
using FY.Service;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using FY.Web.Apps;
using NHibernate.Criterion;

namespace FY.Web.Controllers
{
    public class RoleController : BaseController
    {
       
        #region 角色管理
        public ActionResult Index(int pageIndex=1)
        {

            int count = 0;
            //查询指定索引页的的角色信息
            IList<Role> list = Container.Instance.Resolve<IRoleService>().GetPaged(null, null, pageIndex,PagerHelper.PageSize, out count);

            //将结果转换为PageList对象，以供分页控件使用
            PageList<Role> pageList = list.ToPageList<Role>(pageIndex,PagerHelper.PageSize, count);

            //返回到Index的强类型视图
            return View(pageList);
        }
        #endregion


        #region 角色创建

        [HttpGet]
        public ActionResult Create()
        {
            Role role = new Role();
            return View(role);
        }

        [HttpPost]
        public ActionResult Create(Role role)
        {
            if (ModelState.IsValid)//如果role实体的数据合法
            {
                //根据Createrole(role)创建角色;
                if (Container.Instance.Resolve<IRoleService>().Createrole(role))
                {
                    ModelState.AddModelError("RoleName", "角色存在");
                    return View(role);
                }
                else
                {return RedirectToAction("Index");}
            }
            return View(role);
        }
        #endregion


        #region 角色修改
        [HttpGet]
        public ActionResult Edit(int id)
        {
            //根据id获取当前行的角色信息
            Role model= Container.Instance.Resolve<IRoleService>().Get(id);

            //返回新建视图（修改创建共用一个视图）
            return View("Create", model);
        }
        [HttpPost]
        public ActionResult Edit(Role model)
        {
            if (ModelState.IsValid)//如果role实体的数据合法
            {
                //调用RoleEdit(model)判断角色名是否存在存在返回提示反之存储;
                if (Container.Instance.Resolve<IRoleService>().RoleEdit(model))
                {
                    ModelState.AddModelError("RoleName", "角色已存在");
                    return View("Create", model);
                }
                else
                {
                    //跳转到Index页面
                    return RedirectToAction("Index");
                }
            }
            return View("Create", model);
        }
        #endregion


        #region 删除
        public ActionResult Delete(int id)
        {
            //根据角色ID查询角色信息
            Role model = Container.Instance.Resolve<IRoleService>().Get(id);

            //判断角色是否已分配了用户，如果有，则不能删除
            if (model.UserList == null || model.UserList.Count == 0)
                Container.Instance.Resolve<IRoleService>().Delete(model);
            else
            {
                //返回错误提示
            }
            //跳转到Index页面
            return RedirectToAction("Index");
        }
        #endregion    


        #region 注销激活
        public ActionResult SwitchStatus(int id)
        {
            
            Container.Instance.Resolve<IRoleService>().SwitchStatus(id);//调用业务逻辑层方法，切换用户状态

            return RedirectToAction("Index");//跳转到列表页面
        }
        #endregion


        #region 菜单权限
        [HttpGet]
        public ActionResult Authorize(int id)
        {
            //根据id获取角色
            Role model = Container.Instance.Resolve<IRoleService>().Get(id);
            //获取所有菜单信息
            IList<SystemFunction> FunctionList = Container.Instance.Resolve<ISystemFunctionService>().GetAll().Where(m => m.IsShow == true).ToList();
            if (model.SysFunctionList != null)
            {
                foreach (var item in FunctionList)
                {
                    if (model.SysFunctionList.Where(m => m.ID == item.ID).Count() > 0)
                        item.IsShow = true;
                }
            }
            //菜单信息传入视图
            ViewBag.List = FunctionList;
            return View(model);
        }

        [HttpPost]
        public ActionResult Authorize(int roleId, string hdSelectedIds)
        {
            //用菜单id绑定到角色菜单权限
            Container.Instance.Resolve<IRoleService>().AssignRole(roleId, hdSelectedIds.Replace(",,", ","));
            return RedirectToAction("Index");
        }
        #endregion
    }
}
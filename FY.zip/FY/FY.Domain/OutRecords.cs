﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Castle.ActiveRecord;
using System.ComponentModel.DataAnnotations;
using NHibernate.Criterion;
//using System.Web.Mvc;

namespace FY.Domain
{
    [ActiveRecord("Outrecords")]
    public class OutRecords : EntityBase
    {
        /// <summary>
        /// 主键
        /// </summary>
        /// 调用EntityBase类实现

        //数量
        [Property(NotNull = true)]
        public int Quantity { get; set; }

        //时间
        [Property(NotNull = true)]
        public DateTime Time { get; set; }

        //金额
        [Property(NotNull = true)]
        [Required(ErrorMessage = "必须填写字段信息哦。")]
        [Display(Name = "Money", Description = "金额")]
        public double Money { get; set; }

        //销售人
        [BelongsTo(Type = typeof(User), Column = "UserId", Lazy = FetchWhen.OnInvoke)]
        public User UserId { get; set; }

        //消费人
        [BelongsTo(Type = typeof(Customer), Column = "CustomerId", Lazy = FetchWhen.OnInvoke)]
        public Customer CustomerId { get; set; }


        //进货单
        [HasMany(typeof(OutRecord), Table = "OutRecord", ColumnKey = "OutRecordsId", Cascade = ManyRelationCascadeEnum.SaveUpdate, Lazy = true, Inverse = false)]
        public IList<OutRecord> OutRecordlist { get; set; }
    }
}

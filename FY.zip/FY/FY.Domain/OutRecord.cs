﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Castle.ActiveRecord;
using System.ComponentModel.DataAnnotations;
using NHibernate.Criterion;
//using System.Web.Mvc;

namespace FY.Domain
{
    [ActiveRecord("Outrecord1")]
    public class OutRecord : EntityBase
    {
        /// <summary>
        /// 主键
        /// </summary>
        /// 调用EntityBase类实现

        //数量
        [Property(NotNull = true)]
        public int OutQuantity { get; set; }

        //时间
        [Property(NotNull = true)]
        public DateTime OutTime { get; set; }


        //商品
        [BelongsTo(Type = typeof(Goods), Column = "GoodsId", Lazy = FetchWhen.OnInvoke)]
        public Goods GoodsId { get; set; }

        
        [BelongsTo(Type = typeof(User), Column = "UserId", Lazy = FetchWhen.OnInvoke)]
        public User UserId { get; set; }

        //商品种类
        [BelongsTo(Type = typeof(Customer), Column = "CustomerId", Lazy = FetchWhen.OnInvoke)]
        public Customer CustomerId { get; set; }

        //单号
        [BelongsTo(Type = typeof(OutRecords), Column = "OutRecordsId", Lazy = FetchWhen.OnInvoke)]
        public OutRecords Number { get; set; }
    }
}

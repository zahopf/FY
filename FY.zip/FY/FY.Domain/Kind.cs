﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Castle.ActiveRecord;
//using System.ComponentModel.DataAnnotations;

namespace FY.Domain
{
    [ActiveRecord]
    public class Kind : EntityBase
    {
        /// <summary>
        /// 主键
        /// </summary>
        /// 调用EntityBase类实现

        [Property( NotNull = true)]
        public string KindName { get; set; }

        [HasAndBelongsToMany(typeof(Goods),
            Table = "Goods_Kind",
            ColumnKey = "KindId",
            ColumnRef = "GoodsId",
            Cascade = ManyRelationCascadeEnum.None,
            Inverse = false)]
        public virtual IList<Goods> GoodsList { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Castle.ActiveRecord;
using System.ComponentModel.DataAnnotations;
using NHibernate.Criterion;
using System.Web.Mvc;


namespace FY.Domain
{
    [ActiveRecord("Goods")]
    public class Goods:EntityBase
    {
        /// <summary>
        /// 主键
        /// </summary>
        /// 调用EntityBase类实现

        //商品名字
        [Property( NotNull = true)]
        [Required(ErrorMessage = "不能为空")]
        [Display(Name = "商品名字")]
        public virtual string GoodsName { get; set; }

        //折扣
        [Property(NotNull = true)]
        [Required(ErrorMessage = "不能为空")]
        [Range(0.1, 1)] 
        [Display(Name = "折扣")]
        public float Number { get; set; }

        //进货价格
        [Property(NotNull = true)]
        [Required(ErrorMessage = "不能为空")]
        [Display(Name = "进价")]
        public virtual float InnPrice { get; set; }

        //出货价格
        [Property(NotNull = true)]
        [Required(ErrorMessage = "不能为空")]
        [Display(Name = "售价")]
        public virtual float OutPrice { get; set; }

        //库存
        [Property(NotNull = true)]
        [Required(ErrorMessage = "不能为空")]
        [Display(Name = "库存")]
        public virtual int Stock { get; set; }

        [BelongsTo(Type = typeof(Kind), Column = "KindId", Lazy = FetchWhen.OnInvoke)]
        public virtual Kind KindId { get; set; }


        [HasMany(typeof(OutRecord), Table = "[OutRecord]", ColumnKey = "GoodsId", Cascade = ManyRelationCascadeEnum.SaveUpdate, Lazy = true, Inverse = false)]
        public IList<OutRecord> OutRecords { get; set; }

        [HasMany(typeof(InnRecord), Table = "[InnRecord]", ColumnKey = "GoodsId", Cascade = ManyRelationCascadeEnum.SaveUpdate, Lazy = true, Inverse = false)]
        public virtual IList<InnRecord> InnRecordList { get; set; }

    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Castle.ActiveRecord;
using System.ComponentModel.DataAnnotations;
using NHibernate.Criterion;
using System.Web.Mvc;

namespace FY.Domain
{
    [ActiveRecord("Customer")]
    public class Customer:EntityBase
    {
        //客户名
        [Property(NotNull = true)]
        [StringLength(20, ErrorMessage = "长度不能操作20.")]
        [Required(ErrorMessage = "必须填写字段信息哦。")]
        [Display(Name = "CustomerName", Description = "客户名")]
        public virtual string CustomerName { get; set; }

        //是否为VIP
        [Property(NotNull = true)]
        public virtual bool VIP { get; set; }

        //客户电话号码
        [Property(NotNull = true)]
        [StringLength(15, ErrorMessage = "长度不能操作15.")]
        [Display(Name = "Number", Description = "客户电话号码")]
        public virtual string Number { get; set; }

        //积分（一元一积分）
        [Property]
        [Display(Name = "Integral", Description = "积分（一元一积分")]
        public virtual int Integral { get; set; }


        //消费记录
        [HasMany(typeof(OutRecord), Table = "[OutRecord]", ColumnKey = "CustomerId", Cascade = ManyRelationCascadeEnum.SaveUpdate, Lazy = true, Inverse = false)]
        public IList<OutRecord> OutRecords { get; set; }
    }
}

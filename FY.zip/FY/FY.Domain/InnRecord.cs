﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Castle.ActiveRecord;
using System.ComponentModel.DataAnnotations;
using NHibernate.Criterion;
//using System.Web.Mvc;

namespace FY.Domain
{
    [ActiveRecord("InnRecord")]
    public class InnRecord : EntityBase
    {
        /// <summary>
        /// 主键
        /// </summary>
        /// 调用EntityBase类实现

        //数量
        [Property( NotNull = true)]
        public int InnQuantity { get; set; }

        //时间
        [Property( NotNull = true)]
        public DateTime InnTime { get; set; }

        //商品
        [BelongsTo(Type = typeof(Goods), Column = "GoodsId", Lazy = FetchWhen.OnInvoke)]
        public Goods GoodsId { get; set; }

        //进货人
        [BelongsTo(Type = typeof(User), Column = "UserId", Lazy = FetchWhen.OnInvoke)]
        public User UserId { get; set; }

        //商品种类
        [BelongsTo(Type = typeof(Kind), Column = "KindId", Lazy = FetchWhen.OnInvoke)]
        public Kind KindId { get; set; }

        //单号
        [BelongsTo(Type = typeof(InnRecords), Column = "InnRecordsId", Lazy = FetchWhen.OnInvoke)]
        public InnRecords Number { get; set; }
    }
}
